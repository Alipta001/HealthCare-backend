const os = require("os");

console.log("platform", os.platform());

console.log("user Info", os.userInfo());

console.log("cpu arc", os.arch());

console.log("Free memory",os.freemem())
console.log("Total Memory",os.totalmem())